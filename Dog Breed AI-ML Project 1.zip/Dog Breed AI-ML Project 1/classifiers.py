from torchvision import models, transforms
from PIL import Image
import torch

def classifier(image_path, model_name):
    # Define transforms for the image
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    
    # Load the image
    image = Image.open(image_path).convert('RGB')
    image = preprocess(image).unsqueeze(0)
    
    # Load the model
    if model_name == 'vgg':
        model = models.vgg16(pretrained=True)
    elif model_name == 'alexnet':
        model = models.alexnet(pretrained=True)
    elif model_name == 'resnet':
        model = models.resnet50(pretrained=True)
    else:
        raise ValueError("Model not supported")
    
    # Set model to evaluation mode
    model.eval()
    
    # Make prediction
    with torch.no_grad():
        output = model(image)
    
    # Load class names
    with open('imagenet_classes.txt') as f:
        class_names = [line.strip() for line in f.readlines()]
    
    # Get the predicted class
    _, predicted_idx = torch.max(output, 1)
    return class_names[predicted_idx.item()]
