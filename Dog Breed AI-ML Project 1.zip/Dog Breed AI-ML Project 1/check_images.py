import argparse
import time
from os import listdir
from classifier import classifier

# Define function to get command line arguments
def get_input_args():
    parser = argparse.ArgumentParser()
    
    # Add command line arguments
    parser.add_argument('--dir', type=str, default='pet_images/', 
                        help='path to the folder of pet images')
    parser.add_argument('--arch', type=str, default='vgg', 
                        help='CNN model architecture to use')
    parser.add_argument('--dogfile', type=str, default='dognames.txt', 
                        help='text file with dog names')

    return parser.parse_args()

# Define function to get pet labels from images
def get_pet_labels(image_dir):
    pet_labels = {}
    for image_name in listdir(image_dir):
        if image_name[0] != ".":
            pet_label = " ".join(image_name.lower().split('_')[:-1])
            pet_labels[image_name] = [pet_label]
    return pet_labels

# Define function to adjust results for dog classification
def adjust_results4_isadog(results, dogfile):
    dognames = set()
    with open(dogfile, 'r') as f:
        for line in f:
            dognames.add(line.strip())
    for key in results:
        truth, model_label, _ = results[key]
        is_dog = 1 if truth in dognames else 0
        classified_as_dog = 1 if model_label in dognames else 0
        results[key].extend([is_dog, classified_as_dog])

# Define function to print results
def print_results(results, model):
    n_images = len(results)
    n_correct_dogs = sum((1 for res in results.values() if res[2] == 1 and res[3] == 1))
    n_dogs_img = sum((1 for res in results.values() if res[2] == 1))
    n_correct_notdogs = sum((1 for res in results.values() if res[2] == 0 and res[3] == 0))
    n_notdogs_img = n_images - n_dogs_img
    n_correct_breed = sum((1 for res in results.values() if res[2] == 1 and res[1] == res[0]))
    
    print(f"\nResults for model: {model}")
    print(f"Number of images: {n_images}")
    print(f"Number of dog images: {n_dogs_img}")
    print(f"Number of 'not-a' dog images: {n_notdogs_img}")
    print(f"Number of correct dog matches: {n_correct_dogs}")
    print(f"Number of correct breed matches: {n_correct_breed}")
    print(f"Number of correct 'not-a' dog matches: {n_correct_notdogs}")

# Main program function
def main():
    # Start timing
    start_time = time.time()
    
    # Get command line arguments
    in_arg = get_input_args()
    
    # Get pet labels
    pet_labels = get_pet_labels(in_arg.dir)
    
    # Classify images
    results = {}
    for key in pet_labels:
        model_label = classifier(in_arg.dir + key, in_arg.arch).lower().strip()
        truth = pet_labels[key][0]
        results[key] = [truth, model_label, int(truth in model_label)]
    
    # Adjust results for dog classification
    adjust_results4_isadog(results, in_arg.dogfile)
    
    # Print results
    print_results(results, in_arg.arch)
    
    # End timing
    end_time = time.time()
    total_time = end_time - start_time
    print(f"Total execution time: {total_time:.2f} seconds")

# Run the main function
if __name__ == "__main__":
    main()
